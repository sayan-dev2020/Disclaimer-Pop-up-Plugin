<?php

/*
 * Trigger this file on plugin uninstall
 */
/**
 * @package ToodllePlugin
 */

if (! defined('WP_UNINSTALL_PLUGIN')) exit;
// delete multiple options
$options = array(
    'toddlle_settings_input_field',
    'toddlle_settings_checkbox_page',
    'toddlle_settings_checkbox_post',
);
foreach ($options as $option) {
    if (get_option($option)) delete_option($option);
}
