<?php
/**
 * @package ToodllePlugin
 * Settings Page Template
 */
?>
    <!DOCTYPE html>
    <html>
    <head>
        <style>
            .alert {
                padding: 20px;
                background-color: grey;
                color: black;
            }

            .closebtn {
                margin-left: 15px;
                color: white;
                font-weight: bold;
                float: right;
                font-size: 22px;
                line-height: 20px;
                cursor: pointer;
                transition: 0.3s;
            }

            .closebtn:hover {
                color: black;
            }

            div#toddle-settings-border {
                border-bottom: double;
            }
        </style>

    </head>
    <body>

    <div class="row">
        <div class="col-lg-12">

        </div>
        <div class="col-lg-11">

            <?php //Callback function for settings input field
            function toddle_input_field_callback()
            {
                $toddle_input_field = get_option('toddlle_settings_input_field');

                ?>

                <textarea name="toddlle_settings_input_field" rows="4" cols="50"><?php echo (get_option('toddlle_settings_input_field') ? esc_attr( get_option('toddlle_settings_input_field') ) : 'Before entering this website please read the following information carefully. By entering this site you are acknowledging that you have read the terms and condition.'); ?>
                </textarea>

                <?php
            } ?>

            <?php
            function toddle_checkbox_callback_page()
            {
                ?>
                <input type="hidden" id="toddle_plugin" name="toddle_plugin" value="{enabled=false}">

                <input type="checkbox" id="toddlle_settings_checkbox_page" name="toddlle_settings_checkbox_page"
                       value="1" <?php echo get_option('toddlle_settings_checkbox_page') ? 'checked' : '' ?> />

                <?php
            } ?>

            <?php
            function toddle_checkbox_callback_post()
            {
                ?>
                <input type="hidden" id="toddle_plugin" name="toddle_plugin" value="{enabled=false}">

                <input type="checkbox" id="toddlle_settings_checkbox_post" name="toddlle_settings_checkbox_post"
                       value="1" <?php echo get_option('toddlle_settings_checkbox_post') ? 'checked' : '' ?> />

                <?php
            } ?>

            <div class="wrap">
                <img style="width: 100px" src="<?php echo plugin_dir_url( dirname( __FILE__ ) ) . '/assets/images/Toddle-icon.png'; ?>">
                <form action="options.php" method="post">

                    <?php
                    // security field
                    settings_fields('toddle_plugin');
                    ?>

                    <?php

                    // output settings section here
                    do_settings_sections('toddle_plugin');
                    ?>

                    <?php
                    // save settings button
                    submit_button('Save Settings');
                    ?>
                </form>
            </div>

        </div>
    </div>

    </body>
    </html>
<?php