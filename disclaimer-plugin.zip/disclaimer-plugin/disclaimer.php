<?php
/**
 * @package ToodllePlugin
 */
/*
Plugin name: Toddle Plugin
Plugin URI: https://www.toddleapp.com/
Description: Custom Wordpress disclaimer pop-up plugin
Version: 1.0
Author: Sayan Majumdar
Author URI: https://www.toddleapp.com/
License: GPLv2 or later
Text Domain: toddle-plugin
*/

/*
 * This plugin is built for wordpress websites and it is a free software to use.

 Copyright © 2021 Teacher Tools Pvt. Ltd.
 */
defined('ABSPATH') or die('Hey it is just a plugin');
if (file_exists(dirname(__FILE__) . '/vendor/autoload.php')) {
    require_once dirname(__FILE__) . '/vendor/autoload.php';


}

use Inc\Activate;
use Inc\Deactivate;

if (!class_exists('toddlePlugin')) {
    class toddlePlugin
    {
        //basically used for global(we can put action hooks)
        public $plugin;

        function __construct()
        {
            $this->plugin = plugin_basename(__FILE__);

        }


        //function called register to handle style scripts separately and not during the initialization(we can put action hooks)
        function register()
        {
            //Back-end plugin enqueue scripts & styles both
            add_action('admin_enqueue_scripts', array($this, 'backend_enqueue_scripts'));
            //Front-end plugin enqueue scripts & styles both
            add_action('wp_enqueue_scripts', array($this, 'frontend_enqueue_scripts'));
            //Plugin Menus
            add_action('admin_menu', array($this, 'add_admin_pages'));
            //Settings init() with the admin_init hook
            add_action('admin_init', array($this, 'settings_init'));
            //Plugin action links
            add_filter("plugin_action_links_$this->plugin", array($this, 'settings_link'));
            //To enable the pop-up for page
            add_action('wp_footer', array($this, 'enable_popup_page'));
            //To enable the posts and post types
            add_action('wp_footer', array($this, 'enable_popup_post'));
            //For Plugin activation redirection
            add_action('admin_init', array($this, 'toddle_plugin_redirect'));
        }

        //to link settings menu with the required php page
        public function settings_link($links)
        {
            $settings_link = '<a href="options-general.php?page=toddle_plugin">Configuration</a>';
            array_push($links, $settings_link);
            return $links;
        }

        //function to redirect to my plugin admin menu on activation
        function toddle_plugin_redirect()
        {
            if (get_option('toddle_plugin_do_activation_redirect', false)) {
                delete_option('toddle_plugin_do_activation_redirect');
                if (!isset($_GET['activate-multi'])) {
                    //redirection url
                    wp_redirect("options-general.php?page=toddle_plugin");

                }
            }
        }

        /*
     * ********************************
     * For Settings Page
     * ********************************
     * */
        public static function settings_init()
        {
            // Setup settings section
            add_settings_section(
                'settings_section',//slug section
                '  <div class="alert" id="parent">
            <span class="closebtn" id="toddle-close-btn">&times;</span>
            <strong>WELCOME</strong> to Toddle App Disclaimer Pop-up plugin.
        </div>
        <h4>Settings Configuration</h4>
        <div id="toddle-settings-border"></div>
        <script> 
            const targetDiv = document.getElementById("parent");
            const btn = document.getElementById("toddle-close-btn");
            btn.onclick = function () {
                if (targetDiv.style.display !== "none") {
                    targetDiv.style.display = "none";
                } else {
                    targetDiv.style.display = "block";
                }
            };
        </script>',
                '',
                'toddle_plugin'//menu settings page slug
            );
            // Register input field
            register_setting(
                'toddle_plugin',//menu settings page slug
                'toddlle_settings_input_field',//register settings slug
                array(
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'default' => ''
                ));
            // Register checkbox for page
            register_setting(
                'toddle_plugin',//menu settings page slug
                'toddlle_settings_checkbox_page'//register settings slug
            );
            // Register checkbox for posts
            register_setting(
                'toddle_plugin',//menu settings page slug
                'toddlle_settings_checkbox_post'//register settings slug
            );
            // Add text fields
            add_settings_field(
                'toddlle_settings_input_field',//register settings slug
                __('Text Content', 'my-textdomain'),//input field title and textdomain
                'toddle_input_field_callback',//callback function name(settings.php)
                'toddle_plugin',//menu settings page slug
                'settings_section'//settings section id
            );

            // Add checkbox for page
            add_settings_field(
                'toddlle_settings_checkbox_page',//register settings slug
                __('Enable Pop-Up For Pages', 'my-textdomain'),//input field title and textdomain
                'toddle_checkbox_callback_page',//callback function name(settings.php)
                'toddle_plugin',//menu settings page slug
                'settings_section'//settings section id
            );
            // Add checkbox for post
            add_settings_field(
                'toddlle_settings_checkbox_post',//register settings slug
                __('Enable Pop-Up For Posts', 'my-textdomain'),//input field title and textdomain
                'toddle_checkbox_callback_post',//callback function name(settings.php)
                'toddle_plugin',//menu settings page slug
                'settings_section'//settings section id
            );

        }

        //Enabling pop-up for page
        function enable_popup_page()
        {
            if (get_post_type() === 'page') {
                // Check if the checkbox for page is checked or not
                if (get_option('toddlle_settings_checkbox_page') ? 'checked' : '') {
                    ?>

                    <div id="cookiePopup">
                        <span class="closebtn" id="toddle-popup-close-btn">&times;</span>
                        <h4 class="toddle-pop-up-heading">DISCLAIMER</h4>
                        <p><?php echo(get_option('toddlle_settings_input_field') ? esc_attr(get_option('toddlle_settings_input_field')) : 'Before entering this website please read the following information carefully. By entering this site you are acknowledging that you have read the terms and condition.'); ?></p>
                        <button id="acceptCookie">ACCEPT</button>
                    </div>
                    <?php
                }
            }
        }

        //Enabling pop-up for posts and post types
        function enable_popup_post()
        {
            if (is_single()) {
                // Check if the checkbox for page is checked or not
                if (get_option('toddlle_settings_checkbox_post') ? 'checked' : '') {
                    ?>

                    <div id="cookiePopup">
                        <span class="closebtn" id="toddle-popup-close-btn">&times;</span>
                        <h4 class="toddle-pop-up-heading">DISCLAIMER</h4>
                        <p><?php echo(get_option('toddlle_settings_input_field') ? esc_attr(get_option('toddlle_settings_input_field')) : 'Before entering this website please read the following information carefully. By entering this site you are acknowledging that you have read the terms and condition.'); ?></p>
                        <button id="acceptCookie">ACCEPT</button>
                    </div>
                    <?php
                }
            }
        }


        //to create Plugin menus
        public function add_admin_pages()
        {
            add_options_page('Toddle Plugin', 'Disclaimer', 'manage_options', 'toddle_plugin', array($this, 'settings_page'), 'dashicons-admin-plugins', 10);

        }


        public function settings_page()
        {
            require_once plugin_dir_path(__FILE__) . 'templates/settings.php';
        }

        function activate()
        {
            Activate::activate();

        }

        function deactivate()
        {
            Deactivate::deactivate();
        }

        function backend_enqueue_scripts()
        {
            wp_register_style('bootstrap-style', 'https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css');
            wp_enqueue_style('bootstrap-style');

        }

        function frontend_enqueue_scripts()
        {
            wp_register_script('popup-js', plugin_dir_url(__FILE__) . '/js/pop-up.js', array('jquery'), '0.0.1', true);
            wp_enqueue_script('popup-js');
            wp_enqueue_style('toddlepluginstyle-css', plugin_dir_url(__FILE__) . '/assets/css/pluginstyle.css');

        }


    }
}

if (class_exists('toddlePlugin')) {
    $toddlePlugin = new toddlePlugin('Toddle Plugin initialized');//initializing the class called toddlePlugin
    $toddlePlugin->register(); //triggering register method inside the class
}

//Activation Hook
register_activation_hook(__FILE__, array($toddlePlugin, 'activate'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($toddlePlugin, 'deactivate'));
