<?php
/**
 * @package ToodllePlugin
 */

namespace Inc;
class Activate
{
    public static function activate()
    {
        flush_rewrite_rules();
        if (!current_user_can('activate_plugins'))
            return;

        {
            //adding option to redirect
            add_option('toddle_plugin_do_activation_redirect', true);
        }
        }

}